KNIGHT
------
By [SIMON KLIT-JOHNSON](https://github.com/simonpacis)

Move with WASD, attack with E and dodge with Q.

You're Artore the Puny, littlebrother and inferior to your great big brother, King Arthur.

There have been speculations that the village alchemist, Nefarious Richard, has developed a potion that will allow him to turn into a highly dangerous bat-like creature. You've embarked on a quest to slay Nefarious Richard, who rumor will have it has had too much of his own potion, and is now permanently a bat-like creature. Your big brother King Arthur has promised you that if you slay Nefarious Richard, you earn the rights to the throne!

Good luck!
