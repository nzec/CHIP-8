﻿Score as many points as you can!
Each turn, place one of the three random tiles adjacent to the last tile placed.
#### types of tile:
**hut**  :+1 point. place another bonus hut!  
![hut](http://tann.space/games/civiliz8n/hutborder.png)  
**garden**  : +2 points. if in a connected group of exactly 3 gardens, +4 points instead  
![garden](http://tann.space/games/civiliz8n/gardenborder.png)  
**meeting circle**  : +1 point. when you completely surround this tile, +5 more points  
![meeting](http://tann.space/games/civiliz8n/meetingborder.png)  
**shrine**  : +5 points only if >2 hexes away from all other shrines  
![shrine](http://tann.space/games/civiliz8n/shrineborder.png)  
**temple**  : +1 point per different adjacent tile. other temples don’t count due to religious competition by-laws  
![temple](http://tann.space/games/civiliz8n/templeborder.png)  
**forester**  : +1 point. cuts down all adjacent trees for +1 point each  
![logger](http://tann.space/games/civiliz8n/loggerborder.png)  
**trees**  : randomly placed at the start. must cut them down with a forester in order to put tiles on top  
![trees](http://tann.space/games/civiliz8n/treesborder.png)

#### r to restart once you finish
