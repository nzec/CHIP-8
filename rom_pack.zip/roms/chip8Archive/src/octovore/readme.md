O C T O V O R E
===============
a game of hungry hungry octopods

play as a starving octopus who just has to eat everything in sight, from crumbs to fishies to donuts. you control its ever-extending arms as it frenzies for food.

you must collect every piece of food to advance to the next level. can you beat all 9?

for an extra challenge, try raising the clock speed above the default 120 cycles/frame ;)

controls
========
menu
----
- 4 (C) to procede through menus and start the game
- R (D) to toggle between menu options

left arm
--------
the left arm controls WASD style, but shifted up a row

- 2 (2) to steer the left arm up
- Q (4) to steer the left arm left
- W (5) to steer the left arm down
- E (6) to steer the left arm right

right arm
---------
the right arm similarly controls WASD style, but shifted down a row

- S (8) to steer the right arm up
- Z (A) to steer the right arm left
- X (0) to steer the right arm down
- C (B) to steer the right arm right

shoutouts
---------
thank you to

@ColourTann - for the name octovore!

@lindseybieda - for brainstorming the central mechanics with me!
