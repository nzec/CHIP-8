This isn't a game, rather it is an implementation of [1D Cellular Automata](http://mathworld.wolfram.com/CellularAutomaton.html) because those are cool.

This version is 150 bytes even, and loops through and shows the first 28 (or so) steps of various rules for 1D CAs. I start at rule 20, just because that's where it starts to get interesting.

This is, in reality, pretty slow - the version as you see it is running at 1000 cycles/second. I think I could write a faster one with a tradeoff in program size.

For bragging rights: if I don't include the rule number drawing then it goes down to 115 bytes!
