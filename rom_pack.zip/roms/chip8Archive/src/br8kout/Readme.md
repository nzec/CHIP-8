You can't even imagine how amazing this breakout clone is!

WONDER as you watch a ball bounce back and forth

AMAZE at the pixel perfect collision detection

DIE when your ball reaches the bottom of the screen

LAUGH when you inevitably discover bugs in the game

MOVE your paddle with "A" and "D"

MARVEL that anyone read this far down the list!
