﻿
# Skyward

All of her life Amy has lived in the darkness, in the safety of the caverns her village has called home. Legends tell of a crystal above that will grant anyone a single wish, but no one has seen the sky in the generations. Enraptured by these tales, she packs for a journey to see for herself if these stories are true. Armed with only a few spears and rations for the climb, she sets off skyward to create a legend of her own...

## How to Play

Move Amy to the left with  `A`, and to the right with  `D`

Jump with  `W`, and press  `W`  again while mid-air to jump again.

Throw a spear with  `S`. You can have up to 3 spears on the screen at a time. Use spears to defeat enemies and create platforms to help you climb up.

## Levels

There are no maps of the dark caverns and what lies above, so each time you play these areas will be different! Once Amy has finished exploring a level she will be able to start from the beginning of the next, so don't give up! Can you conquer the caverns, the jungle, and ancient sky islands all in one go? See how quickly you can make it to the top!

About The Team
