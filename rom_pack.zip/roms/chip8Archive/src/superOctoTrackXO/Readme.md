Super Octo Track X-O
====================
A very simple music player based on the XO-Chip audio system played with the keypad. F and B change tempo, 0 erases the track. 1 2 3 4 C add bits to the note to be played. Hold 0 while playing to make a new note. Hold A as the cursor finishes the loop to shorten the loop by 32. Press 7 to switch between play mode and edit mode. Press 8 to advance tick in edit mode. Hold E to advance or 9 to reverse through tracks. Only works as the cursor finishes the loop. There are 8 tracks.
