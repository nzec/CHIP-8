It's downwell, but on the chip-8! Instructions are explained in game.

You can press [F/v] to skip to the hardest level first.

There was an ending planned, but...

you know how it is.

--- POSTMORTEM 11/27/19 ---

I remember being really disappointed when the contest ended and I had not 
finished building all the features that I had planned, but looking back on it
now, what's there is really fun, and I don't even remember what it was that I
had yet to finish. I think I could have restricted the randomization of the 
platforms a little bit more to make the game have less impossible states,
and remembered that the buttons on the COSMAC had different names than the
default octo layout to make the prompts match the real buttons when it was run
on a real COSMAC (still so cool!!). It was nostalgic to try to figure out chip8
programming and read my old code after a couple years -- better than I thought
it would be. Happy Hacking!

tinaun
2019