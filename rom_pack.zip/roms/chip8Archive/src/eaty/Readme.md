I recovered this program from a cassette tape I purchased on Ebay. Comments and indentifiers are all mine, obviously- Octo's disassembler was a big help.

As far as I can tell, "Eaty The Alien" was developed by a crack team at RCA in 1982 following a request from director Steven Spielberg to try adapting his latest film into a video game. Upon seeing the first prototypes he apparently changed his mind and pitched the idea to Atari. The RCA team hastily removed as many references to the original license as possible from their prototype and tried selling the game anyway.

My research shows that only 73 copies of the game were sold, and this is most likely captured from the last surviving tape. A single page from the manual survived the trip here, but it provides enough explanation to get the basic idea. Playing through it, I can't help but wonder whether Howard Scott Warshaw saw "Eaty" and tried to borrow ideas for his own adaptation...

![Manual Page 3](manual.jpg)
