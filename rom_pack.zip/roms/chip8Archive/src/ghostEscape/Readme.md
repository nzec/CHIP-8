Ghost Escape!
=============
Seek revenge on mortal men in this exciting adventure!

Play as Harold the Ghost, undead leader of the fearsome hoards of hell, on a quest to cleanse the world of human life. Use your powerful attacks to lay waste to the enemies of evil. Command minions to mutual destruction of the works of man. Employ the beasts of land and winged creatures of the sky through psychic manipulation to their ultimate doom as pawns beneath your will.

Timing is key!

Attack in waves of perfect timing to maintain your numbers. A miss-timed attack will reduce your armies numbers. Lose your army and the war is lost. Fail to attack in time and the human forces will fight back and overwhelm the vile army at your command, resulting in instant loss, for you!

Press X when it's lined up.
