It is a dark and stormy night. A murder has been committed...
=============================================================
Track down a murder weapon and identify the killer to bring them to justice, but be careful- take too long in your investigation and you may become hunted yourself!

(Warning: the introductory sequence of this game contains high-contrast flashing effects.)

Controls
--------
- Arrow keys or ASWD move and change selections.
- Space or E advanced dialog, confirms selections, and searches the surrounding area for clues.
- In the unlikely event it should come to fisticuffs, space attacks, left and right keys move, and the up key blocks.

On mobile devices, dragging or swiping can be used as an alternative to arrow keys, and taps can be used in place of pressing space.

About
-----
This game was made using Octo, a browser-based IDE for a modern incarnation of the CHIP-8 platform, as part of the 6th annual Octojam. Gameplay is inspired by the 1983 DOS classic, [Sleuth](https://en.wikipedia.org/wiki/Sleuth_(video_game)).
