ASWD move

E resets the current level

When you've finished the game, make your own levels:

[slipedit](http://beyondloom.com/tools/slipedit.html)
