Year of 1987… American Navy has finally hunted down legendary TYPHOON class submarine. She's now resting at the bottom of the ocean.

Year of 2027… Remains of the soviet AI became self-aware and evolved into thriving underwater city.

Reconnaissance satellites detected unusual thermal and nuclear signatures. Shortly, american intelligence sent a team to inflitrate it…

Overworld: WASD

Battle: WASD, E select, Q back

Game Over screen: R - restart X - exit C - clear save

[Sources](https://github.com/whoozle/red-october-v)
