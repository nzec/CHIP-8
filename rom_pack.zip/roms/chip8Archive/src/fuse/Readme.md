Assemble lines to guide a burning fuse. Don't let it burn out!

Press WASD to move the current line fragments and E to lay them down. You cannot lay down a line overlapping any existing lines.

This game is written to conform to a moderately realistic CHIP-8 clock rate and instruction set.
