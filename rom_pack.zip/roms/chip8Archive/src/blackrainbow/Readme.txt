G O O D L U C K ,
B A R R Y ! B R I N G
B A C K T H E
M O T H E R L O D E . . .
A S W D   M O V E
X P A U S E
