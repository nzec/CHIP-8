Bad Kaiju Ju
============
The year is 1977. 90% of the world's landmass is now underwater and the world is at war. Floating cities are often targets for armoured, explosive-laden ships and there is only one line of defense... 

Cutting-edge science has managed to breed and control huge jellyfish like monsters, capable of sinking the ships. By implanting cybernetic hardware into the Kaijus' brains the scientists are able to visualise their moves and coordinate strikes. 

As the leading navy commander of PortSheaf, you are responsible for controlling the Kaiju and saving the city. 

Using your 1977 COSMAC VIP, will you be able to use your Chip 8 visualisation of the high fidelity visceral world combat and Save The Day? 

W to attack (5 key). The boats will stop attacking when you have succeeded. 

(Originally created as part of [Ludum Dare 33](http://ludumdare.com/compo/ludum-dare-33/?action=preview&uid=41319))
